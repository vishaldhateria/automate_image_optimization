/*
 * This external script is part of the rewrite_javascript example.
 * This comment will be removed.
 */
// First inject the state into the document. This comment will also be removed.
  document.write("External " + state);
  state += 1;  // Then update it.
